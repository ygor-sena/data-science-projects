# Mercadinho Fácil — Quinzena 5

Base inicial de desenvolvimento do MVP do Projeto Integrador.

## Stack
- Django
- Django REST Framework
- PostgreSQL
- HTML + CSS + JavaScript
- Git/GitHub (controle de versões)

## Funcionalidades desta versão
- Login do usuário
- Cadastro de categorias
- Cadastro de produtos
- Consulta/pesquisa de estoque
- Registro de entrada
- Registro de saída
- Atualização automática do estoque
- Estoque mínimo
- Produtos sem estoque
- Controle de validade
- Produtos próximos do vencimento
- Produtos vencidos
- API REST

## 1. Criar ambiente
python -m venv .venv

Windows:
.venv\Scripts\activate

Linux/macOS:
source .venv/bin/activate

## 2. Instalar dependências
pip install -r requirements.txt

## 3. Criar banco PostgreSQL
Crie um banco chamado `mercadinho_facil`.

Exemplo:
CREATE DATABASE mercadinho_facil;

## 4. Configurar ambiente
Copie `.env.example` para `.env` e informe usuário/senha do PostgreSQL.

## 5. Criar tabelas Django
python manage.py makemigrations
python manage.py migrate

## 6. Criar usuário para entrar no sistema
python manage.py createsuperuser

## 7. Executar
python manage.py runserver

Abra:
http://127.0.0.1:8000/

API:
http://127.0.0.1:8000/api/produtos/
http://127.0.0.1:8000/api/categorias/
http://127.0.0.1:8000/api/movimentacoes/
http://127.0.0.1:8000/api/produtos/alertas/

## 8. Testes automatizados
Os testes seguem a pirâmide de testes (Martin Fowler): muitos testes
rápidos na base, poucos testes lentos no topo.

| Camada | Pasta | O que testa | Banco |
|---|---|---|---|
| Unitário | `tests/unit/` | Regras de estoque e alertas (`estoque/services.py`), validação dos serializers | Não |
| Integração | `tests/integration/` | Restrições do banco e todos os endpoints da API | PostgreSQL |
| E2E | `tests/e2e/` | Jornadas do usuário: login, CSRF, cadastro, movimentação; navegador real com Playwright | PostgreSQL |

Instalar dependências de desenvolvimento:

    pip install -r requirements-dev.txt
    python -m playwright install chromium

Executar:

    pytest                    # todos
    pytest -m unit            # só a base da pirâmide (menos de 1 s)
    pytest -m integration
    pytest -m e2e
    pytest --cov=estoque --cov-report=term-missing

O usuário do PostgreSQL configurado no `.env` precisa ter permissão para
criar bancos, pois o pytest cria e remove o banco `test_mercadinho_facil`.
Os testes de navegador são ignorados se o Playwright não estiver instalado.

Testes marcados como `xfail` documentam bugs conhecidos; quando o bug for
corrigido, o teste passa a falhar como "XPASS" e o marcador deve ser removido.

## Observação
Esta é uma base acadêmica para a Quinzena 5. Ainda devem ser desenvolvidos/refinados: testes automatizados, acessibilidade completa, VLibras, deploy em nuvem, autorização por perfil e melhorias de segurança.


## Acessibilidade e VLibras

A interface inclui a integração do **VLibras**, recurso que auxilia na tradução de conteúdos do site para Libras. Também foram incluídos recursos básicos de acessibilidade, como foco visível para navegação por teclado, labels nos campos e atributos ARIA em elementos relevantes.

> O VLibras é um recurso de acessibilidade e não substitui as boas práticas de acessibilidade web.
